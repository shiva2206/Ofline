import 'package:flutter/material.dart';

const kGrey = Color.fromRGBO(0, 0, 0, 0.69);
const kBlue = Color.fromRGBO(12, 71, 160, 0.8);
const kWhite = Color.fromRGBO(255, 255, 255, 1);

const kRed = Color.fromRGBO(255, 99, 99, 1);
const kChipColor = Color.fromRGBO(236, 237, 241, 0.88);
